package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
	
	// Imported the bytestoHex code
	public String bytesToHex(byte[] bytes) {
		StringBuilder builder = new StringBuilder();
		for (byte b: bytes) {
			builder.append(String.format("%02x", b));
		}
		return builder.toString();
	}
	
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash(){
    	String data 	= "Christopher Daisy Check Sum";	// String with my name
    	String cipher 	= "SHA-256";			// Cipher being used
    	String hash 	= "";					// Initialized the hash
    	byte[] bytes;							// Bytes for MessageDigest
    	
    	// Try-catch for exception handling
    	try {
    		MessageDigest md = MessageDigest.getInstance(cipher);	// Create an MessageDigest instance
    		md.update(data.getBytes());								// Convert into bytes
    		bytes = md.digest();									// Digest the data, and store it in 'bytes'
    		hash = bytesToHex(bytes);								// bytes -> Hexadecimal, store in 'hash'
    		
    	} catch (NoSuchAlgorithmException e){						// If an exception is thrown: print the issue		
    		throw new IllegalStateException("SHA-256 is not avaliable");	
    	}
    	
    	// Display the results
        return "<h1>Data</h1>"
        		+ "<hr> "
        		+ "<p>" + data + "</p>"
        		+ "<h1>Cipher Algorithm Used</h1>"
        		+ "<hr>"
        		+ "<p>" + cipher + "</p>"
        		+ "<h1>Bytes</h1>"
        		+ "<hr>"
        		+ "<p>" + bytes + "</p>"
        		+ "<h1>Check Sum Value</h1>"
        		+ "<hr>"
        		+ "<p>" + hash + "</p>";
    }
}
